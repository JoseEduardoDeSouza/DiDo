<?php
include_once 'src/DAO/BaseDAO.php';
include_once 'src/Entities/UsuarioEntity.php';

class UsuarioDAO extends BaseDAO
{
  public function inserir($usuario){
    $sql = "INSERT INTO usuario  (pNome, uNome, email, senha) VALUES (" .
      "'" . $usuario->getPNome() . "'," .
      "'" . $usuario->getUNome() . "'," .
      "'" . $usuario->getEmail() . "'," .
      "'" . $usuario->getSenha() . "')";

    return $this->executaSQL($sql);
  }
  public function alterar($usuario){
    $sql = "UPDATE usuario SET " .
      "pNome = '" . $usuario->getPNome() . "'," .
      "uNome = '" . $usuario->getUNome() . "'," .
      "senha = '" . $usuario->getSenha() . "' " .
      "WHERE email = '" . $usuario->getEmail() . "'";

    return $this->executaSQL($sql);
  }

  public function remover($usuario){
    $sql = "DELETE FROM usuario WHERE email = '$usuario->email'";

    return $this->executaSQL($sql);
  }

  public function verificaExistencia($email){
    $sql = "SELECT email FROM usuario WHERE email = '$email'";

    $res = $this->selecionar($sql);

    if ($res->num_rows > 0) {
      return true;
    }
    return false;
  }

  public function selecionaTodos(){
    $sql = 'SELECT email, senha, pNome, uNome FROM usuario';

    $res = $this->selecionar($sql);
    $retorno = new UsuarioEntity();
    $retorno = array();

    if ($res->num_rows > 0) {
      while($row = $res->fetch_assoc()) {
				array_push($retorno, new UsuarioEntity($row["pNome"], $row["uNome"], $row["email"], $row["senha"]));
			}
    }
    return $retorno;
  }
  public function seleciona($email){
    $sql = "SELECT email, senha, pNome, uNome FROM usuario WHERE email = '$email'";

    $res = $this->selecionar($sql);

    if ($res->num_rows > 0) {
      if ($row = $res->fetch_assoc()) {
        return new UsuarioEntity($row["pNome"], $row["uNome"], $row["email"], $row["senha"]);
      }
    }
    return false;
  }
}
