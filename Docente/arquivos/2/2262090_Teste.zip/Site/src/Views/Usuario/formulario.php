<!DOCTYPE html>
<html lang="pt-BR" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <form action="<?= $action  ?>"  method="post">

      <div>
        <label for="pNome">Primeiro Nome:</label>
        <input type="text" name="pNome" id="pNome" value="<?= isset($usuario) ? $usuario->getPNome() : "" ?>" required>
      </div>
      <div>
        <label for="uNome">Último Nome:</label>
        <input type="text" name="uNome" id="uNome" value="<?= isset($usuario) ? $usuario->getUNome() : "" ?>" required>
      </div>
      <?php if (isset($usuario)) { ?>
        <div>
          <label for="email">Email: <?= $usuario->getEmail() ?></label>
        </div>
        <input type="hidden" name="email" value="<?= $usuario->getEmail() ?>">
      <?php }
      else { ?>
        <div>
          <label for="email">Email:</label>
          <input type="email" name="email" id="email" value="<?= isset($usuario) ? $usuario->getEmail() : "" ?>" required>
        </div>
      <?php } ?>

      <div>
        <label for="senha">Senha:</label>
        <input type="password" name="senha" id="senha" value="" required>
      </div>

      <input type="submit" value="Enviar">
    </form>
  </body>
</html>
