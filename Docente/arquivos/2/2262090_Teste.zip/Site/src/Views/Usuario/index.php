<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <table>
      <tr>
        <td>Primeiro Nome</td>
        <td>Segundo Nome</td>
        <td>Email</td>
        <td>Senha</td>
        <td>Ação</td>
      </tr>
      <?php foreach ($usuarios as $usuario) {  ?>
        <tr>
          <td><?= $usuario->getPNome() ?></td>
          <td><?= $usuario->getUNome() ?></td>
          <td><?= $usuario->getEmail() ?></td>
          <td><?= $usuario->getSenha() ?></td>
          <td><a href="/Usuario/formAlterar?email=<?= $usuario->getEmail() ?>">Alterar</a>
          </td>
        </tr>
      <?php } ?>
    </table>

    <a href="/Usuario/formInserir">Cadastrar Novo</a>
  </body>
  <style media="screen">
    table, td {
      border: solid 1px black;
    }
  </style>
</html>
