<?php
include_once('src/DAO/UsuarioDAO.php');

class UsuarioModel {
  private $dao;

  public function __construct(){
    $this->dao = new UsuarioDAO();
  }
  public function inserir($usuario){
    if (!$this->dao->verificaExistencia($usuario->getEmail())) {
      $this->dao->inserir($usuario);
      return true;
    }
    else {
      return false;
    }
  }
  public function alterar($usuario){
    if ($res = $this->dao->seleciona($usuario->getEmail())) {
      if ($usuario->getSenha() == $res->getSenha()) {
        $this->dao->alterar($usuario);
        return true;
      }
    }
    else {
      return false;
    }
  }
  public function selecionaTodos(){
    return $this->dao->selecionaTodos();
  }
  public function seleciona($email){

    return $this->dao->seleciona($email);
  }
}
