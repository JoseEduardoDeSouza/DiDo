<?php

class UsuarioEntity {
  private $pNome;
  private $uNome;
  private $email;
  private $senha;

  public function __Construct($pNome = null, $uNome = null, $email = null, $senha = null){
    $this->pNome = $pNome;
    $this->uNome = $uNome;
    $this->email = $email;
    $this->senha = $senha;
  }

  public function getPNome(){
    return $this->pNome;
  }
  public function getUNome(){
    return $this->pNome;
  }
  public function getEmail(){
    return $this->email;
  }
  public function getSenha(){
    return $this->senha;
  }
  public function setPNome($pNome){
    $this->pNome = $pNome;
  }
  public function setUNome($pUnome){
    $this->pUome = $uNome;
  }
  public function setEmail($email){
    $this->email = $email;
  }
  public function setSenha($senha){
    $this->senha = $senha;
  }
}
