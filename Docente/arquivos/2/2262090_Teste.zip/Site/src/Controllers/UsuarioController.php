<?php

include_once('src/Entities/UsuarioEntity.php');
include_once('src/Models/UsuarioModel.php');

class UsuarioController {
  private $model;

  public function __Construct(){
      $this->model = new UsuarioModel();
  }

  public function index(){
    $usuarios = $this->model->selecionaTodos();
    require_once 'src/Views/Usuario/index.php';
  }

  public function formInserir(){
    $action = "/usuario/inserir";
    require_once 'src/Views/Usuario/formulario.php';
  }

  public function formAlterar($params){
    $usuario = $this->model->seleciona($params['email']);
    if (!$usuario) {
      header('Location: /Usuario');
    }
    else {
      $action = "/usuario/alterar";
      require_once 'src/Views/Usuario/formulario.php';

    }
  }

  public function inserir($params){
    $usuario = new UsuarioEntity($params['pNome'], $params['uNome'], $params['email'], $params['senha']);
    $this->model->inserir($usuario);

    header('Location: /Usuario');
  }

  public function alterar($params){
    $usuario = new UsuarioEntity($params['pNome'], $params['uNome'], $params['email'], $params['senha']);
    $this->model->alterar($usuario);

    header('Location: /Usuario');
  }

  public function remover(){

  }
}
