<?php

session_start();

include_once 'src/Controllers/ProfessorController.php';
include_once 'src/Controllers/DiciplinaController.php';

$controller = 'professorcontroller';
$action = 'index';

/*
Se for diferente da index, por exemplo localhost/usuario/inserir
*/

if ($_SERVER['REQUEST_URI'] != '/') {

		$class = explode('/', substr($_SERVER['REQUEST_URI'], 1));


		$controller =  $class[0] . 'Controller';


		if(count($class) > 1){
			//die($class[1]);
			// strpos = retorna a posição
			//que um caracter está em uma string
			$pos = strpos($class[1], "?");


			if ($pos === false) {
				$action = $class[1];
			}
			else {
				$action = substr($class[1], 0, $pos);
			}
		}

}
if ($_SERVER['REQUEST_METHOD'] == "GET") {
	$params = $_GET;
}
else if($_SERVER['REQUEST_METHOD'] == "POST"){
	$params = $_POST;
}
$controller = new $controller;
$controller->$action($params);

 ?>
