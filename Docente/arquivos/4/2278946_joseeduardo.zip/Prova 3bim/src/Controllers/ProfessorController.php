<?php

include_once('src/Entities/ProfessorEntity.php');
include_once('src/Models/ProfessorModel.php');

class ProfessorController {
  private $model;

  public function __Construct(){
      $this->model = new ProfessorModel();
  }

  public function index(){
    $professores = $this->model->selecionaTodos();
    require_once 'src/Views/Professor/index.php';

  }

  public function formInserir(){
    $action = "/Professor/inserir";
    require_once 'src/Views/Professor/formulario.php';
  }
  public function inserir($params){
    $usuario = new ProfessorEntity($params['nome'], $params['aNascimento'], $params['apelido'], $params['email']);
    $this->model->inserir($usuario);

    header('Location: /Professor');
  }

  public function formAlterar($params){
    $professor = $this->model->seleciona($params['id']);
    if (!$professor) {
      header('Location: /Professor');
    }
    else {
      $action = "/Professor/alterar";
      require_once 'src/Views/Professor/formulario.php';

    }
  }



  public function alterar($params){
    $professor = new ProfessorEntity($params['nome'],
    $params['aNascimento'],
    $params['apelido'],
    $params['email'],
    $params["id"]);
    $this->model->alterar($professor);

    header('Location: /Professor');
  }
  public function formRemover($params){
    $professor = $this->model->seleciona($params['id']);
    if (!$professor) {
      header('Location: /Professor');
    }
    else {

      $this->model->remover($professor);
      header('Location: /Professor');

    }
  }
}
