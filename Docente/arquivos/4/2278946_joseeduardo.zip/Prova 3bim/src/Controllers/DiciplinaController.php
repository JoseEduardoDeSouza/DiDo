<?php

require_once 'src/Models/DiciplinaModel.php';
require_once 'src/Entities/DiciplinaEntity.php';

class DiciplinaController{
  private $model;

  function __construct(){
    $this->model = new DiciplinaModel();
  }

  function index(){
    $todos = $this->model->selecionaTodos();
    require_once 'src/Views/Diciplina/index.php';
  }

  function formInserir(){
    $action = '/diciplina/inserir';
    $prof_model = new ProfessorModel();
    $professores = $prof_model->selecionaTodos();

    require_once 'src/Views/Diciplina/formulario.php';
  }

  function inserir($params){
    $diciplina = new DiciplinaEntity(null, $params['professor'],$params['nome']);
    $this->model->inserir($diciplina);

    header('Location: /Diciplina');
  }


}
