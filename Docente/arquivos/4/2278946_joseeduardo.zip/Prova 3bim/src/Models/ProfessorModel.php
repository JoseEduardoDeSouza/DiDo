<?php
include_once('src/DAO/ProfessorDAO.php');

class ProfessorModel {
  private $dao;

  public function __construct(){
    $this->dao = new ProfessorDAO();
  }
  public function inserir($professor){
    if (!$this->dao->verificaExistencia($professor->getEmail())) {
      $this->dao->inserir($professor);
      return true;
    }
    else {
      return false;
    }
  }
  public function alterar($professor){
    if ($res = $this->dao->seleciona($professor->getId())) {
        $this->dao->alterar($professor);
        return true;
    }
    else {
      return false;
    }
  }
  function remover($professor){
      $this->dao->remover($professor);


  }

  public function selecionaTodos(){
    return $this->dao->selecionaTodos();
  }
  public function seleciona($id){
    return $this->dao->seleciona($id);
  }
}
