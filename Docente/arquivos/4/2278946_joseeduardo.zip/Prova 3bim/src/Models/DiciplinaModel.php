<?php
require_once 'src/DAO/DiciplinaDAO.php';

class DiciplinaModel{
  private $dao;

  function __construct(){
    $this->dao = new DiciplinaDAO();
  }
  function inserir($diciplina){
    if ($diciplina->getNome() != "") {
      if (!$this->dao->verificaNome($diciplina->getNome())) {
        $this->dao->inserir($diciplina);
      }
    }
  }


  function selecionaTodos(){
    return $this->dao->selecionaTodos();
  }

  function selecionaUnico($id){
    return $this->dao->selecionaUnico($id);
  }
}
