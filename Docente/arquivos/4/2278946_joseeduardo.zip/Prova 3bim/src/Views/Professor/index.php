<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <table>
      <tr>
        <td>Nome</td>
        <td>Ano de nascimento</td>
        <td>Apelido</td>
        <td>Email</td>
        <td>Ação</td>
        <td>Remoção</td>
      </tr>
      <?php foreach ($professores as $professor) {  ?>
        <tr>
          <td><?= $professor->getNome() ?></td>
          <td><?= $professor->getANascimento() ?></td>
          <td><?= $professor->getApelido() ?></td>
          <td><?= $professor->getEmail() ?></td>
          <td><a href="/Professor/formAlterar?id=<?= $professor->getId() ?>">
            Alterar</a>
          </td>
          <td><a href="/Professor/formRemover?id=<?= $professor->getId() ?>">
            Remover</a>
          </td>
        </tr>
      <?php } ?>
    </table>

    <a href="/Professor/formInserir">Cadastrar Novo</a>
    <a href="/Diciplina/formInserir">Cadastrar Diciplina</a>
  </body>
  <style media="screen">
    table, td {
      border: solid 1px black;
    }
  </style>
</html>
