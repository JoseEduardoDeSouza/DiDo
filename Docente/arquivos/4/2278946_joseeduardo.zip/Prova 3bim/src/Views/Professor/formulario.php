<!DOCTYPE html>
<html lang="pt-BR" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <form action="<?= $action  ?>"  method="post">

      <div>
        <label for="nome">Nome:</label>
        <input type="text" name="nome" id="nome" value="<?= isset($professor) ? $professor->getNome() : "" ?>" required>
      </div>
      <div>
        <label for="aNascimento">Ano de Nascimento:</label>
        <input type="text" name="aNascimento" id="aNascimento" value="<?= isset($professor) ? $professor->getANascimento() : "" ?>" required>
      </div>
      <div>
        <label for="apelido">Apelido:</label>
        <input type="text" name="apelido" id="apelido" value="<?= isset($professor) ? $professor->getApelido() : "" ?>" required>
      </div>
        <div>
          <label for="email">Email:</label>
          <input type="email" name="email" id="email" value="<?= isset($professor) ? $professor->getEmail() : "" ?>" required>

          <input type="hidden" name="id" value="<?= isset($professor) ? $professor->getId() : "" ?>" >
        </div>



      <input type="submit" value="Enviar">
    </form>
  </body>
</html>
