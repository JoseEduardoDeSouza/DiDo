
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Marcas Cadastradas</title>
  </head>
  <body>
    <table>
      <tr>
        <th>Nome</th>
        <th>Nome da Disciplina</th>
        <th>Excluir</th>
      </tr>
      <?php foreach ($todos as $diciplina) { ?>
        <tr>
          <td><?= $diciplina->getNome() ?></td>
          <td><?= $diciplina->getProfId() ?></td>
          <td><a href="/marca/formAlterar?id=<?= $diciplina->getId()?>">Alterar</a></td>
          <td> <a href="/marca/remover?id=<?= $diciplina->getId()?>">Remover</a> </td>
        </tr>
      <?php } ?>
    </table>

  </body>
</html>
