<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Cadastro de Diciplina</title>
  </head>
  <body>
    <form action="<?= $action ?>" method="post">
      <label for="nome">Nome:</label>
      <input type="text" name="nome" value="<?= isset($diciplina) ? $diciplina->getNome() : ""?>">
      <label for="prof">Professor:</label>
      <select name="professor" if="prof">
        <?php
          if (isset($professores)) {
            foreach ($professores as $professor) {
              echo "<option name='prof' value=".$professor->getId().">".$professor->getNome()."</option>";
            }

          }
         ?>

      </select>
      <?php if (isset($diciplina)) { ?>
        <input type="hidden" name="id" value="<?= $diciplina->getId() ?>">
      <?php } ?>
      <input type="submit" value="Enviar">
    </form>
  </body>
</html>
