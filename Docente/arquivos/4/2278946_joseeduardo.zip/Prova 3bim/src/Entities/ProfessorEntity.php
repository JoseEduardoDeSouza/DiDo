<?php

class ProfessorEntity {
  private $id;
  private $nome;
  private $aNascimento;
  private $apelido;
  private $email;

  public function __Construct($nome = null,
  $aNascimento = null,
  $apelido = null,
  $email = null,
  $id = null){
    $this->nome = $nome;
    $this->aNascimento = $aNascimento;
    $this->email = $email;
    $this->apelido = $apelido;
    $this->id = $id;
  }

  public function getNome(){
    return $this->nome;
  }
  public function getId(){
    return $this->id;
  }
  public function getANascimento(){
    return $this->aNascimento;
  }
  public function getEmail(){
    return $this->email;
  }
  public function getApelido(){
    return $this->apelido;
  }
  public function setNome($nome){
    $this->nome = $nome;
  }
  public function setUNome($aNascimento){
    $this->aNascimento = $aNascimento;
  }
  public function setEmail($email){
    $this->email = $email;
  }
  public function setSenha($apelido){
    $this->apelido = $apelido;
  }
  public function setId($id){
    $this->id = $id;
  }
}
