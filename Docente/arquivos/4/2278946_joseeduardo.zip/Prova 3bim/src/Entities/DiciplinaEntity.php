<?php

class DiciplinaEntity{
  private $id;
  private $prof_id;
  private $nome;

  function __construct($id = null,$prof_id = null, $nome = null){
    $this->id = $id;
    $this->prof_id = $prof_id;
    $this->nome = $nome;
  }

  function setId($id){
    $this->id= $id;
  }
  function setProfId($prof_id){
    $this->prof_id= $prof_id;
  }
  function setNome($nome){
    $this->nome= $nome;
  }
  function getId(){
    return $this->id;
  }
  function getProfId(){
    return $this->prof_id;
  }
  function getNome(){
    return $this->nome;
  }

}
