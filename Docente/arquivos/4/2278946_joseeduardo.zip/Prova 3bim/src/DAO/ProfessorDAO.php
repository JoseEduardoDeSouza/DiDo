<?php
include_once 'src/DAO/BaseDAO.php';
include_once 'src/Entities/ProfessorEntity.php';

class ProfessorDAO extends BaseDAO
{
  public function inserir($professor){
    $sql = "INSERT INTO Professor  (nome, ano_nascimento, apelido, email) VALUES (" .
      "'" . $professor->getNome() . "'," .
      "'" . $professor->getANascimento() . "'," .
      "'" . $professor->getApelido() . "'," .
      "'" . $professor->getEmail() . "')";

    return $this->executaSQL($sql);
  }
  public function alterar($professor){
    $sql = "UPDATE Professor SET " .
      "nome = '" . $professor->getNome() . "'," .
      "ano_nascimento = '" . $professor->getANascimento() . "'," .
      "apelido = '" . $professor->getApelido() . "'," .
      "email = '" . $professor->getEmail() . "' " .
      "WHERE id = " . $professor->getId();

    return $this->executaSQL($sql);
  }

  public function remover($professor){
    $sql = "DELETE FROM Professor WHERE id = '".$professor->getId()."'";

    return $this->executaSQL($sql);
  }

  public function verificaExistencia($email){
    $sql = "SELECT email FROM Professor WHERE email = '$email'";

    $res = $this->selecionar($sql);

    if ($res->num_rows > 0) {
      return true;
    }
    return false;
  }

  public function selecionaTodos(){
    $sql = 'SELECT id, nome, ano_nascimento, apelido, email FROM Professor';

    $res = $this->selecionar($sql);
    $retorno = array();

    if ($res->num_rows > 0) {
      while($row = $res->fetch_assoc()) {
        $user = new ProfessorEntity($row["nome"],
        $row["ano_nascimento"],
        $row["apelido"],
        $row["email"],
        $row["id"]);
				array_push($retorno, $user);
			}
    }
    return $retorno;
  }
  public function seleciona($id){
    $sql = "SELECT id, nome, ano_nascimento, apelido, email FROM Professor
    WHERE id = $id";

    $res = $this->selecionar($sql);

    if ($res->num_rows > 0) {
      if ($row = $res->fetch_assoc()) {
        return new ProfessorEntity($row["nome"], $row["ano_nascimento"],
        $row["apelido"], $row["email"], $row["id"]);
      }
    }
    return false;
  }
}
