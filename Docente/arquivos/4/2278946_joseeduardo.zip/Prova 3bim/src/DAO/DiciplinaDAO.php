<?php
include_once 'src/DAO/BaseDAO.php';
include_once 'src/Entities/DiciplinaEntity.php';

class DiciplinaDAO extends BaseDAO{
  function verificaNome($nome){
    $sql = "SELECT id FROM Disciplina WHERE nome = '$nome'";

    $res = $this->selecionar($sql);

    if ($res->num_rows > 0) {
      return true;
    }
    return false;
  }
  function selecionaUnico($id){
    $sql = "SELECT id, nome FROM marca WHERE id = $id";

    $res = $this->selecionar($sql);

    if ($res->num_rows > 0) {
      if ($row = $res->fetch_assoc()) {
          return new MarcaEntity($row['id'], $row['nome']);
      }
    }
    return false;
  }

  function verificaRemocao($id){
    $sql = "SELECT id FROM marca WHERE id = $id";

    $res = $this->selecionar($sql);

    if ($res->num_rows > 0) {
      return true;
    }
    return false;
  }


  function verificaAlteracao($id, $nome){
    $sql = "SELECT id FROM marca WHERE nome = '$nome ' AND id <> $id";

    $res = $this->selecionar($sql);

    if ($res->num_rows > 0) {
      return false;
    }
    return true;
  }

  function alterar($marca){
    $sql = "UPDATE marca SET " .
    "nome = '" . $marca->getNome() . "' " .
    "WHERE id = " . $marca->getId();

    return $this->executaSQL($sql);
  }
  function remover($marca){
    $sql = "DELETE FROM marca WHERE id=".$marca->getId()."";

    return $this->executaSQL($sql);
  }

  function selecionaTodos(){
    $sql = 'select Disciplina.id as id, Professor.nome as nome,Disciplina.nome as Dnome from Disciplina,Professor where Professor.id=Disciplina.id_professor;';

    $res = $this->selecionar($sql);
    $retorno =  array();
    if ($res->num_rows > 0) {
      while ($row = $res->fetch_assoc()) {
        array_push($retorno, new DisciplinaEntity($row['id'],$row['Dnome'],
          $row['nome']));
      }
    }

    return $retorno;
  }

  function inserir($diciplina){
    $prof_id=$diciplina->getProfId();
    $prof_nome= $diciplina->getNome();
    $sql = "INSERT INTO Disciplina (id_professor,nome) VALUES ($prof_id,'$prof_nome')";

    return $this->executaSQL($sql);
  }
}
