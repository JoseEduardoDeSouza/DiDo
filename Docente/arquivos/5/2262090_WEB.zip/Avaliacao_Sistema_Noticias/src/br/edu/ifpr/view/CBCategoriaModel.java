/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifpr.view;

import br.edu.ifpr.model.bean.Categoria;
import java.util.List;
import javax.swing.DefaultComboBoxModel;

/**
 *
 * @author baro
 */
public class CBCategoriaModel extends DefaultComboBoxModel<Categoria>{

    public CBCategoriaModel(List<Categoria> categorias) {
        super();
        for (Categoria categoria : categorias) {
            addElement(categoria);
        }
    }

    @Override
    public Categoria getSelectedItem() {
        return (Categoria) super.getSelectedItem(); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
    
    
}
