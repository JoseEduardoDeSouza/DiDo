/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifpr.model.dao;

import br.edu.ifpr.model.bean.Comentario;
import br.edu.ifpr.model.bean.Usuario;
import br.edu.ifpr.model.util.PersistenceUtil;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

/**
 *
 * @author baro
 */
public class ComentarioDAO extends GenericDAO<Integer, Comentario>{
    
    public ComentarioDAO(EntityManager em) {
        super(em);
    }

    public List<Comentario> getComentarioPorParametroDoTexto(String valorDeBusca) {
        TypedQuery<Comentario> query = super.em.createNamedQuery(
                "Comentario.findByText", Comentario.class);
        query.setParameter("parametroDeBusca", "%" + valorDeBusca + "%");
        return query.getResultList();
    }
    
    public List<Comentario> getComentariosPorUsuario(Usuario usuario) {
        TypedQuery<Comentario> query = super.em.createQuery(
                "SELECT c FROM Comentario c WHERE c.usuario.id = :id", Comentario.class);
        query.setParameter("id", usuario.getId());
        return query.getResultList();
    }
}
