/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifpr.model.util;

import br.edu.ifpr.model.bean.Categoria;
import br.edu.ifpr.model.bean.Comentario;
import br.edu.ifpr.model.bean.Noticia;
import br.edu.ifpr.model.bean.Usuario;
import br.edu.ifpr.model.dao.CategoriaDAO;
import br.edu.ifpr.model.dao.ComentarioDAO;
import br.edu.ifpr.model.dao.NoticiaDAO;
import br.edu.ifpr.model.dao.UsuarioDAO;
import java.util.List;
import java.util.Set;

/**
 *
 * @author baro
 */
public class Teste {
    
    public static void main(String[] args) {
        
        UsuarioDAO daoUsuario = new UsuarioDAO();
        
        //UsuarioDAO daoUsuario = new UsuarioDAO(PersistenceUtil.getEntityManager());
        
        Usuario usuario = daoUsuario.retrieve(1);
        
        ComentarioDAO dao = new ComentarioDAO(PersistenceUtil.getEntityManager());
        
        List<Comentario> comentarios = dao.getComentariosPorUsuario(usuario);
        
        for (Comentario comentario : comentarios) {
            System.out.println("Texto do comentário: " + comentario.getTexto());
        }
        
        PersistenceUtil.stopSessionFactory();

        /*CategoriaDAO dao = new CategoriaDAO(PersistenceUtil.getEntityManager());
        
        List<Categoria> categorias = dao.getCategoriasPorNome("E");        
        for (Categoria categoria: categorias) {
            System.out.println(categoria.getNome());
        }
        
        System.out.println("");
        
        categorias = dao.getCategoriasPorNome("A");        
        for (Categoria categoria: categorias) {
            System.out.println(categoria.getNome());
        }
        
        System.out.println("");
        
        categorias = dao.getCategoriasPorNome("As");        
        for (Categoria categoria: categorias) {
            System.out.println(categoria.getNome());
        }
        */
         
        /*
        NoticiaDAO dao = new NoticiaDAO(PersistenceUtil.getEntityManager());
        //List<Noticia> noticias = dao.getNoticiasPorTermoDoTexto("Gabi");
        
        System.out.println(noticias.size());
        
        for (Noticia noticia : noticias) {
            System.out.println(noticia.getTitulo());
            System.out.println(noticia.getTexto());
            System.out.println(noticia.getCategoria().getNome());
            Set<Comentario> comentarios = noticia.getComentarios();
            System.out.println("------Comentarios-------");
            for (Comentario comentario : comentarios) {
                System.out.println(comentario.getTexto());
            }
            System.out.println("------------------------------");
        }
        */
        
    }
}
