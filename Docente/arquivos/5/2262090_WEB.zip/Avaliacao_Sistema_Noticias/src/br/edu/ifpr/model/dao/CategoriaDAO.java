/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifpr.model.dao;

import br.edu.ifpr.model.bean.Categoria;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

/**
 *
 * @author baro
 */
public class CategoriaDAO extends GenericDAO<Integer, Categoria>{
    
    public CategoriaDAO(EntityManager em) {
        super(em);
    }
    
    public List<Categoria> getCategoriasPorNome(String paramBusca) {
         
        // Utilizando parâmetros ordinais
        TypedQuery<Categoria> query = super.em.createNamedQuery(
                "Categoria.findByName", Categoria.class);                
        query.setParameter(1, "%" + paramBusca + "%");
        
        return query.getResultList();
        
        // Utilizando parâmetros nomeados
        /*TypedQuery<Categoria> query = super.em.createQuery(
                "SELECT cat FROM Categoria cat WHERE cat.nome LIKE :nome", Categoria.class);
        query.setParameter("nome", paramBusca + "%");*/
        
        // Utiliza Literais
        /*TypedQuery<Categoria> query = super.em.createQuery(
                "SELECT cat FROM Categoria cat WHERE cat.nome LIKE '" 
                        + paramBusca +"%'", Categoria.class);*/
    }
    
}
