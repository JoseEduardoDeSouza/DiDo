/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifpr.view;

import br.edu.ifpr.model.bean.Noticia;
import java.util.List;
import javax.swing.AbstractListModel;

/**
 *
 * @author baro
 */
public class ListNoticiasModel extends AbstractListModel<String>{

    private List<Noticia> noticias;
    
    public ListNoticiasModel(List<Noticia> noticias) {
        super();
        this.noticias = noticias;
    }
    
    @Override
    public int getSize() {
        return noticias.size();
    }

    @Override
    public String getElementAt(int index) {
        return noticias.get(index).getTitulo();
    }
    
    
}
