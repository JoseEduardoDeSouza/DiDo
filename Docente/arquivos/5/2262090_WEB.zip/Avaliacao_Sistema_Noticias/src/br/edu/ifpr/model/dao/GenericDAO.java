/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifpr.model.dao;

import java.lang.reflect.ParameterizedType;
import java.util.List;
import javax.persistence.EntityManager;

/**
 *
 * @author baro
 */
public class GenericDAO<PK, T> {
    
    protected EntityManager em;

    public GenericDAO(EntityManager em) {
        this.em = em;
    }
    
    public void create(T entity) {
        em.getTransaction().begin();
        em.persist(entity);
        em.getTransaction().commit();
    }
    
    public T retrieve(PK pk) {
        T entity = (T) em.find(getTypeClass(), pk);
        return entity;
    }
    
    public void update(T entity) {
        em.getTransaction().begin();
        em.merge(entity);
        em.getTransaction().commit();
    }
    
    public void delete(PK pk) {
        em.getTransaction().begin();
        T entity = (T) em.find(getTypeClass(), pk);
        em.remove(entity);
        em.getTransaction().commit();
    }
    
    public List<T> findAll() {
        List<T> entities;
        entities = em.createQuery("FROM " + getTypeClass().getName()).getResultList();
        return entities;
    }
    
    /**
     * Retorna a classe do objeto.
     * 
     * O Class<?> significa que pode ser retornado
     * qualquer classe, pois não sabemos qual o tipo
     * da classe
     * 
     * @return Class<?>
     */
    private Class<?> getTypeClass() {
        Class<?> clazz = (Class<?>) ((ParameterizedType) this.getClass().getGenericSuperclass()).getActualTypeArguments()[1];
        return clazz;
    }
}
