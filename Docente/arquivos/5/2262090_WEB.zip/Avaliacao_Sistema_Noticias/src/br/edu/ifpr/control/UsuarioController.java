/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifpr.control;

import br.edu.ifpr.model.bean.Usuario;
import br.edu.ifpr.model.dao.UsuarioDAO;
import br.edu.ifpr.model.negocio.RegrasUsuario;

/**
 *
 * @author baro
 */
public class UsuarioController {
    
    public static boolean usuarioExiste(String email, String senha) {
        RegrasUsuario ru = new RegrasUsuario();
        return ru.verificaUsuario(email, senha);
    }
    
    
    public static Usuario getUsuario(String email, String senha) {
        UsuarioDAO dao = new UsuarioDAO();
        return dao.getUsuario(email, senha);
    }
}
