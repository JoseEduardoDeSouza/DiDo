/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifpr.model.dao;

import br.edu.ifpr.model.bean.Usuario;
import br.edu.ifpr.model.util.PersistenceUtil;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

/**
 *
 * @author baro
 */
public class UsuarioDAO extends GenericDAO<Integer, Usuario>{
    
    public UsuarioDAO(EntityManager em) {
        super(em);
    } 

    public UsuarioDAO() {
        super(PersistenceUtil.getEntityManager());
    }
    
    
 
    public Usuario getUsuario(String email, String senha) {
        
        TypedQuery<Usuario> query = super.em.createNamedQuery(
                "UsuarioEmailSenha", Usuario.class);
        
        /*TypedQuery<Usuario> query = super.em.createNamedQuery(
                "UsuarioEmailSenha", Usuario.class);*/
        query.setParameter("email", email);
        query.setParameter("senha", senha);
        
        Usuario usuario = null;
        
        try {
            usuario = query.getSingleResult();
        } catch (NoResultException e) {
            usuario = null;
        }
        
        return usuario;
    }
}
