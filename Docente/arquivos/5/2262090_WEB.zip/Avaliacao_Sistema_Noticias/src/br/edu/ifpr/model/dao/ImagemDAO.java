/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifpr.model.dao;

import br.edu.ifpr.model.bean.Imagem;
import br.edu.ifpr.model.util.PersistenceUtil;
import java.util.List;
import javax.persistence.EntityManager;

/**
 *
 * @author baro
 */
public class ImagemDAO extends GenericDAO<Integer, Imagem>{
    

    public ImagemDAO(EntityManager em) {
        super(em);
    }
   
}
