/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifpr.model.dao;

import br.edu.ifpr.model.bean.Noticia;
import br.edu.ifpr.model.util.PersistenceUtil;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

/**
 *
 * @author baro
 */
public class NoticiaDAO extends GenericDAO<Integer, Noticia>{
    
    public NoticiaDAO(EntityManager em) {
        super(em);
    }
    
    
    public List<Noticia> getNoticiasPorTitulo(String parametroDeBusca) {
        TypedQuery<Noticia> query = super.em.createNamedQuery(
                "Noticias.findByTitulo", Noticia.class);
        query.setParameter("titulo", "%" + parametroDeBusca.toLowerCase() + "%");
        
        //TypedQuery<Noticia> query2 = super.em.createQuery(
                //"SELECT n FROM Noticia n WHERE n.titulo LIKE %" + parametroDeBusca + "%", Noticia.class);
        
        //"SELECT n FROM Noticia n WHERE LOWER(n.titulo) LIKE %br%"
        return query.getResultList();
    }
    
}
