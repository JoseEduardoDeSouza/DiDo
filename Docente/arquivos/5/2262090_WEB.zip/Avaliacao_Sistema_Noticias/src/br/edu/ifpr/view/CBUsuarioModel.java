/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifpr.view;

import br.edu.ifpr.model.bean.Usuario;
import java.util.List;
import javax.swing.DefaultComboBoxModel;

/**
 *
 * @author baro
 */
public class CBUsuarioModel extends  DefaultComboBoxModel<Usuario>{

    public CBUsuarioModel(List<Usuario> usuarios) {
        super();
        for (Usuario usuario : usuarios) {
            addElement(usuario);
        }
    }

    @Override
    public Usuario getSelectedItem() {
        return (Usuario) super.getSelectedItem();
    }
    
    
}
