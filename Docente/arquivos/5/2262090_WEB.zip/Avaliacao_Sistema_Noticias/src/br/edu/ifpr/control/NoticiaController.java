/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifpr.control;

import br.edu.ifpr.model.bean.Noticia;
import br.edu.ifpr.model.dao.NoticiaDAO;
import br.edu.ifpr.model.util.PersistenceUtil;
import java.util.List;

/**
 *
 * @author baro
 */
public class NoticiaController {
    
    public static List<Noticia> getNoticias(String parametroDeBusca) {
        NoticiaDAO dao = new NoticiaDAO(PersistenceUtil.getEntityManager());
        return dao.getNoticiasPorTitulo(parametroDeBusca);
    }
}
