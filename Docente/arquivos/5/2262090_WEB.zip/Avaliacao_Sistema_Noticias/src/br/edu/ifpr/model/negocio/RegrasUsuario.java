/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifpr.model.negocio;

import br.edu.ifpr.model.bean.Usuario;
import br.edu.ifpr.model.dao.UsuarioDAO;
import br.edu.ifpr.model.util.PersistenceUtil;

/**
 *
 * @author baro
 */
public class RegrasUsuario {
    
    public boolean verificaUsuario(String email, String senha) {
        UsuarioDAO dao = new UsuarioDAO(PersistenceUtil.getEntityManager());
        Usuario usuario = dao.getUsuario(email, senha);
        
        if (usuario == null) {
            return false;
        } else {
            return true;
        }
    }
}
